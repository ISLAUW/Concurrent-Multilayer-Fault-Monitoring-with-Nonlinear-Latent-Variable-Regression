function [num_pc,lamda,T,W] = PCA(X,C_Rate)

[num,n]=size(X);
matrix=cov(X); %求协方差矩阵
[W,lamda]=eig(matrix); %对协方差矩阵进行特征分解，lamda为特征值构成的对角阵，T的列为单位特征向量，且与lamda中的特征值一一对应： 
D=flipud(diag(lamda)); %取对角元素(结果为一列向量)，即lamda值，并上下反转使其从大到小排列，主元个数初值为1，若累计贡献率小于90%则增加主元个数
num_pc=1;                                         
while sum(D(1:num_pc))/sum(D)<C_Rate   
    num_pc=num_pc+1;
end
W=W(:,n-num_pc+1:n); %取与lamda相对应的特征向量
lamda=lamda(n-num_pc+1:n,n-num_pc+1:n);
T=X*W;
end