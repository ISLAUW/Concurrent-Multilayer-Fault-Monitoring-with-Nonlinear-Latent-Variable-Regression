function [T,A,U,Q]=klvr(K1,Y1,a)

kappa = 0.005;

% ———— 赋初值 ————
n = size(K1,1); np = size(Y1,2);

K = zeros(n,n,a); Y = zeros(n,np,a);
K(:,:,1) = K1; Y(:,:,1) = Y1;

for i=1:a              
    U(:,i)=Y(:,1,i);
    itererr=1;
    count=1;
    while norm(itererr)>0.00001
        A(:,i) = pinv(K(:,:,i)'* K(:,:,i) + kappa * eye(n)) * K(:,:,i)* U(:,i);
        T(:,i) = K(:,:,i)*A(:,i); T(:,i)=T(:,i)/norm(T(:,i)); %计算ti(phi(X) scores)
        Q(:,i)=Y(:,:,i)'*T(:,i); Q(:,i)=Q(:,i)/norm(Q(:,i));   
        % Q(:,i)=Y(:,:,i)'*(U(:,i)-T(:,i)); Q(:,i)=Q(:,i)/norm(Q(:,i)); %计算qi(Y loading vector)
        U(:,i) = Y(:,:,i)*Q(:,i); %U(:,i)=U(:,i)/norm(U(:,i)); %计算ui(Y scores)
        %U(:,i) = Y(:,:,i)*Y(:,:,i)'*T(:,i);
        %itererr = T(:,i) - K(:,:,i)*pinv(K(:,:,i)'* K(:,:,i) + kappa * eye(n)) * K(:,:,i)'* U(:,i)/norm(K(:,:,i)*pinv(K(:,:,i)'* K(:,:,i) + kappa * eye(n)) * K(:,:,i)'* U(:,i));
        itererr = U(:,i) - Y(:,:,i)*Y(:,:,i)'*K(:,:,i)*A(:,i);
        norm(itererr);

        if count>1000
           break;
        else
        count=count+1;
        end
    end
    % ————Residual Deflation————            
    C(:,i)=Y(:,:,i)'*T(:,i); 
    %C(:,i)=Y(:,:,i)'*T(:,i)/(T(:,i)'*T(:,i));  
   
    K(:,:,i+1)=K(:,:,i)-T(:,i)*T(:,i)'*K(:,:,i)-K(:,:,i)*T(:,i)*T(:,i)'+T(:,i)*T(:,i)'*K(:,:,i)*T(:,i)*T(:,i)';
    %Y(:,:,i+1)=Y(:,:,i)-T(:,i)*C(:,i)';
    Y(:,:,i+1)=Y(:,:,i)-T(:,i)*T(:,i)'*Y(:,:,i); % 求残差矩阵(resudial correlation matrix) 
end
end
