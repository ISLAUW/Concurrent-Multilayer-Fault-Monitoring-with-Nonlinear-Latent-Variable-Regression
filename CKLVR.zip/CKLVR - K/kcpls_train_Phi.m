function [R,T,Q,U,Vc,Dc,Rc,Tc,Qc,Px,Py,lamda_c,lamda_x,lamda_y,Ac,Ax,Ay,mm,pp,...
    Tc2_lim,Tx2_lim,Qx_lim,Ty2_lim,Qy_lim]...
    =kcpls_train(Phi,Y1,K0,K1,a,sig_k)

% this function trains KCPLS
% X1,Y1 must be autoscaled
% a is the number of KPLS factors
% a can be obtained by running kpls_factor.m, which uses cross-validation

num=size(Phi,1);

%% ———— KPLS ————
[T,Q,U]=kpls(K1,Y1,a);
R=Phi'*U*pinv(T'*K1*U);

%% ———— Predictable Output ————
Yh=T*Q';
[U0,D0,V0]=svd(Yh);

if size(D0,2)==1
    Sc=D0(1);     
else
    Sc=diag(D0); 
    Sc=Sc(diag(D0)>0.001);
end
Ac=length(Sc);
lamda_c=1/(num-1)*diag(Sc.^2);

Vc=V0(:,1:Ac); Dc=D0(1:Ac,1:Ac);
Qc=Vc*Dc;
Rc=R*Q'*Vc*pinv(Dc);
Tc=Yh*Vc*pinv(Dc);  %Tc=Phi*Rc;

%% ———— Unpredictable Output ————
Yct=Y1-Tc*Qc';
[U1,D1,V1]=svd(Yct); Ay=pc_number(Yct); Py=V1(:,1:Ay); 
Ty=Yct*Py; % output pincipal scores
% Yt=Yct-Ty*Py';

if size(D1,2)==1
    Sy=D1(1);
else
    Sy=diag(D1);
end
pp=length(Sy);
%lamda_y=1/(num-1)*diag(Sy(1:Ay).^2); 
lamda_y=1/(num-1)*Ty'*Ty;

%% ———— Output-irrelevant Input ————
Phi_ct=Phi-Tc*(pinv(Rc'*Rc)*Rc'); 
[U2,D2,V2]=svd(Phi_ct); Ax=pc_number(Phi_ct);Px=V2(:,1:Ax); Tx=Phi_ct*Px; %input-principal scores

if size(D2,2)==1
    Sx=D2(1);
else
    Sx=diag(D2);
end
mm=length(Sx);
%lamda_x=1/(num-1)*diag(Sx(1:Ax).^2);
lamda_x=1/(num-1)*Tx'*Tx;

%% ———— KCPLS control limit for detection ————
alpha=0.05; level=1-alpha; 

for i=1:num
    phi=Phi(i,:)';
    tc=Rc'*phi; %1 1
    phi_ct=phi-(pinv(Rc'*Rc)*Rc')'*tc;
    yct=Y1(i,:)'-Qc*tc;

    % ———— Qx_index ————
    Qx_index(i)=phi_ct'*(eye(size(Px*Px'))-Px*Px')*phi_ct;
    % ———— Qy_index ————
    Qy_index(i)=yct'*(eye(size(Py*Py'))-Py*Py')*yct; 
end

ax=mean(Qx_index); bx=var(Qx_index); gx=bx/(2*ax); hx=2*ax^2/bx; 
ay=mean(Qy_index); by=var(Qy_index); gy=by/(2*ay); hy=2*ay^2/by;
%gx=1/(num-1)*sum(Sx(Ax+1:mm).^4)/sum(Sx(Ax+1:mm).^2);
%hx=(sum(Sx(Ax+1:mm).^2))^2/sum(Sx(Ax+1:mm).^4);
%gy=1/(num-1)*sum(Sy(Ay+1:pp).^4)/sum(Sy(Ay+1:pp).^2);
%hy=(sum(Sy(Ay+1:pp).^2))^2/sum(Sy(Ay+1:pp).^4);

% ———— T2_lim ————
Tc2_lim=chi2inv(level,Ac);     % output-relevant fault based on x
Tx2_lim=chi2inv(level,Ax);     % output-irrelevant but input-relevant based on x
Ty2_lim=chi2inv(level,Ay);     % output relevant
%Ty2_lim=(Ay*(num^2-1)/(num*(num-Ay)))*finv(level,Ay,num-Ay);

% ———— Q_lim ————
Qx_lim=gx*chi2inv(level,hx);   % potentially output-relevant based on x
Qy_lim=gy*chi2inv(level,hy);   % output relevant

% ———— display results ————
if Ax+1>mm
    display ('Q_x index=0');
end
      
if Ay+1>pp
    display ('Q_y index=0');
end
