%% ———— Kernel Principal Component Analysis ————
function [Phi_X,Phi_Xt,W,D,i]=KPCA(X1,X1_test,sig_k)

% ———— input ————
%     X  : training data points  (number of samples  x dimension)
%     Xt : testing  data points  (number of samples  x dimension)
%     n_pc : number of principal componets onto which data are projected 
%                                                     par1    par2 
%     type:  'G' Gaussian   Kernel  exp((|x-y|^2)/w)   w       0 
%            'P' Polynomial Kernel  (<x,y>+c)^a:       a       c     

% ———— output ————
%     Phi_X  : projection of training data  onto the first n_pc  principal componets (number of samples  x n_pc)
%     Phi_Xt : projection of testing  data  onto the first n_pc  principal componets (number of samples  x n_pc)
%     W,D  : eigenvectors and eigenvalues of the centralized (cen_K) training data kernel matrix 
%            !!!!  eigenvalues coresponding to the sample covariance matrix are D/(n-1)

[n,dim]=size(X1); [nt,dim]=size(X1_test);

% ———— Kernel matrix construction ————
[cen_K,K]=kernel_function(X1,sig_k);
[cen_Kt,Kt]=kernel_function_test(X1,X1_test,K,sig_k);

% ———— KPCA ————
%[W,D,Exp]=pcacov(cen_K);
%%% this is the pcacov() function from Matlab Statistical Toolbox :
[~,D,W] = svd(cen_K);
D = diag(D);
total_var = sum(D);
Exp=100*D/total_var;
    
% here the eigenvalues and eigenvectors are ordered in decreasing order 
% !!! eigenvalues coresponding to the sample covariance matrix are D/(n-1)
i=1;
while i<10000
    % ———— Training data projection ————
    for k=1:i
        Phi_X(:,k)=W(:,k)*sqrt(D(k));
        Q(:,k)=W(:,k)/(sqrt(D(k)));   
    end
    % ———— Testing data projection ————
    Phi_Xt=cen_Kt*Q;
    if norm(cen_Kt-Phi_Xt*Phi_X')<0.000001
        break;
    else
        i=i+1;
    end
end
    
    

    
    
    