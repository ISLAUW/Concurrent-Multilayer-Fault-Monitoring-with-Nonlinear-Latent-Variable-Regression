function [Tc2_index,Tx2_index,Qx_index,Ty2_index,Qy_index,T2_index]...
    =kclvr_test(K1_test,K0_test,Y1_test,K1,K0,a,sig_k,T,C,U,Vc,Dc,Tc,Qc,Wx,Py,Psi,lamda_c,lamda_x,lamda_y,Ac,Ax,Ay,mm,pp,...
    Tc2_lim,Tx2_lim,Qx_lim,Ty2_lim,Qy_lim)

num=size(K1,1); num_test=size(K1_test,1);
Lambda=1/(num-1)*T'*T;

for i=1:num_test
    % ———— T2_index ————
    kx_new=K1_test(i,:)';
    t_new=pinv(U'*K1*T)*U'*kx_new;
    T2_index(i)=t_new'*inv(Lambda)*t_new;
    
    % ———— Tc2_index ————
    kx_new=K1_test(i,:)';
    t_new=pinv(U'*K1*T)*U'*kx_new;
    tc_new=pinv(Dc)'*Vc'*C*pinv(T'*K1*U)'*U'*kx_new;
    Tc2_index(i)=(num-1)*tc_new'*tc_new; 

    % ———— Tx2_index ————
    tx_new=Wx'*(eye(size(Tc*Psi))-Tc*Psi-K1*Psi'*pinv(Dc)'*Vc'*C*pinv(T'*K1*U)'*U'+Tc*Psi*K1*Psi'*pinv(Dc)'*Vc'*C*pinv(T'*K1*U)'*U')*kx_new;
    Tx2_index(i)=tx_new'*pinv(lamda_x)*tx_new;
    
    % ———— Ty2_index ————
    yct_new=Y1_test(i,:)'-Qc*tc_new; 
    ty_new=Py'*yct_new;  
    Ty2_index(i)=ty_new'*pinv(lamda_y)*ty_new;
    
    % ———— Qx_index ————
%    Qx_index(i)=1-2*tc_new'*Psi*kx_new+tc_new'*Psi*K1*Psi'*tc_new-2*(kx_new'-tc_new'*Psi*K1)*(eye(size(Tc*Psi))-Tc*Psi)'*Wx*tx_new+tx_new'*Wx'*(eye(size(Tc*Psi))-Tc*Psi)*K1*(eye(size(Psi'*Tc'))-Psi'*Tc')*Wx*tx_new;
    part_1=1-2/num*sum(K0_test(i,:))+1/num^2*sum(sum(K0));
    part_2=kx_new'*(eye(size(T*T'))-T*T')*Wx*tx_new-t_new'*T'*K1*(eye(size(T*T'))-T*T')*Wx*tx_new;
    part_3=tx_new'*Wx'*(eye(size(T*T'))-T*T')*K1*(eye(size(T*T'))-T*T')*Wx*tx_new;
    Qx_index(i)=part_1-2*part_2+part_3;    
    
    % ———— Qy_index ————
    Qy_index(i)=yct_new'*(eye(size(Py*Py'))-Py*Py')*yct_new; 
end