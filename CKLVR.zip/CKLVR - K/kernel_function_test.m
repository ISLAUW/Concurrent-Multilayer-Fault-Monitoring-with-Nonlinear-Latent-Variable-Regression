%% ————Kernel Function for Testing————
function [K1_test,K0_test]=kernel_function_test(X1,X1_test,K0,sig_k)
num=size(X1,1); num_test=size(X1_test,1); 
K_test(:,:)=zeros(num_test,num);
for a_test=1:num_test
    for b_test=1:num
        xa_test=X1_test(a_test,:); xb_test=X1(b_test,:); 
        K_test(a_test,b_test)=(norm(xa_test-xb_test))^2; 
    end
end
K0_test=exp(-K_test/sig_k);
Mt=ones(num_test,num)/num;
M=eye(num)-ones(num,num)/num;
K1_test=(K0_test-Mt*K0)*M;
%K1_test=(eye(num)-ones(num,1)*ones(num,1)'/num)*(K0_test-K0*ones(num,1)/num);
end