% ———— Calculate the MSE of KLVR prediction ————
function mse=klvr_mse(X1,Y1,X1_test,Y1_test,a,sig_k)

[K1,K0]=kernel_function(X1,sig_k);
[K1_test,~]=kernel_function_test(X1,X1_test,K0,sig_k);

Y_predict=klvr_predict(K1,Y1,K1_test,a);
Y_error=Y1_test-Y_predict;
mse=sum(sum(Y_error.^2)) /size(Y_predict,1);
end
