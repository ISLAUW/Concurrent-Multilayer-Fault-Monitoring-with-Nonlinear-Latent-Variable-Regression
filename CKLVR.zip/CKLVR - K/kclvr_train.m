function [T,C,U,Vc,Dc,Tc,Qc,Wx,Py,Psi,lamda_c,lamda_x,lamda_y,Ac,Ax,Ay,mm,pp,...
    Tc2_lim,Tx2_lim,Qx_lim,Ty2_lim,Qy_lim,T2_lim]...
    =kclvr_train(K1,K0,Y1,a,sig_k)

% this function trains KCPLS
% X1,Y1 must be autoscaled
% a is the number of KPLS factors
% a can be obtained by running kpls_factor.m, which uses cross-validation

num=size(K1,1);

%% ———— KPLS ————
[T,Q,U,C]=klvr(K1,Y1,a);
% R=Phi'*U*pinv(T'*K1*U);

%% ———— Predictable Output ————
Yh=T*C';
[U0,D0,V0]=svd(Yh);

if size(D0,2)==1
    Sc=D0(1);     
else
    Sc=diag(D0); 
%    Sc=Sc(diag(D0)>0.001);
end
Ac=length(Sc);
lamda_c=1/(num-1)*diag(Sc.^2);

Vc=V0(:,1:Ac); Dc=D0(1:Ac,1:Ac);
Qc=Vc*Dc;
% Rc=R*C'*Vc*pinv(Dc);
Tc=Yh*Vc*pinv(Dc);  % Tc=Phi*Rc;

%% ———— Unpredictable Output ————
Yct=Y1-Tc*Qc';
[U1,D1,V1]=svd(Yct); Ay=pc_number(Yct); Py=V1(:,1:Ay); 
Ty=Yct*Py; % output pincipal scores
% Yt=Yct-Ty*Py';

if size(D1,2)==1
    Sy=D1(1);
else
    Sy=diag(D1);
%    Sy=Sy(diag(D0)>0.0001);
end
pp=length(Sy);
%lamda_y=1/(num-1)*diag(Sy(1:Ay).^2); 
lamda_y=1/(num-1)*Ty'*Ty;

%% ———— Output-irrelevant Input ————
% Phi_ct=Phi-Tc*(pinv(Rc'*Rc)*Rc'); 
% [U2,D2,V2]=svd(Phi_ct); Ax=pc_number(Phi_ct);Px=V2(:,1:Ax); Tx=Phi_ct*Px; %input-principal scores

Psi=pinv(pinv(Dc)'*Vc'*C*pinv(T'*K1*U)'*U'*K1*U*pinv(T'*K1*U)*C'*Vc*pinv(Dc))*pinv(Dc)'*Vc'*C*pinv(T'*K1*U)'*U';
Kc=(eye(size(Tc*Psi))-Tc*Psi)*K1*(eye(size(Psi'*Tc'))-Psi'*Tc'); %Kc=Phi_ct*Phi_ct';

[~,D2,V2]=svd(Kc/num); Ax=pc_number(Kc/num); Wx=V2(:,1:Ax); 
for j=1:size(Wx,2)
    Wx(:,j)=Wx(:,j)/norm(Wx(:,j));
end
Tx=Kc*Wx;

if size(D2,2)==1
    Sx=D2(1);
else
    Sx=diag(D2);
end
mm=length(Sx);
%lamda_x=1/(num-1)*diag(Sx(1:Ax).^2); 
lamda_x=1/(num-1)*Tx'*Tx;

%% ———— KCPLS control limit for detection ————
alpha=0.01; level=1-alpha; 

for i=1:num
    kx=K1(i,:)';
    t=pinv(U'*K1*T)*U'*kx;
    tc=pinv(Dc)'*Vc'*C*pinv(T'*K1*U)'*U'*kx;
    tx=Wx'*(eye(size(Tc*Psi))-Tc*Psi-K1*Psi'*pinv(Dc)'*Vc'*C*pinv(T'*K1*U)'*U'+Tc*Psi*K1*Psi'*pinv(Dc)'*Vc'*C*pinv(T'*K1*U)'*U')*kx;
    
    % ———— Qx_index ————
%    Qx_index(i)=1-2*tc'*Psi*kx+tc'*Psi*K1*Psi'*tc-2*(kx'-tc'*Psi*K1)*(eye(size(Tc*Psi))-Tc*Psi)'*Wx*tx+tx'*Wx'*(eye(size(Tc*Psi))-Tc*Psi)*K1*(eye(size(Psi'*Tc'))-Psi'*Tc')*Wx*tx;
    part_1=1-2/num*sum(K0(i,:))+1/num^2*sum(sum(K0));
    part_2=kx'*(eye(size(T*T'))-T*T')*Wx*tx-t'*T'*K1*(eye(size(T*T'))-T*T')*Wx*tx;
    part_3=tx'*Wx'*(eye(size(T*T'))-T*T')*K1*(eye(size(T*T'))-T*T')*Wx*tx;
    Qx_index(i)=part_1-2*part_2+part_3;  
    % ———— Qy_index ————
    Qy_index(i)=(Y1(i,:)'-Qc*tc)'*(eye(size(Py*Py'))-Py*Py')*(Y1(i,:)'-Qc*tc); 
end

ax=mean(Qx_index); bx=var(Qx_index); gx=bx/(2*ax); hx=2*ax^2/bx; 
ay=mean(Qy_index); by=var(Qy_index); gy=by/(2*ay); hy=2*ay^2/by;

% ———— T2_lim ————
T2_lim=chi2inv(level,a);
Tc2_lim=chi2inv(level,Ac);     % output-relevant fault based on x
Tx2_lim=chi2inv(level,Ax);     % output-irrelevant but input-relevant based on x
Ty2_lim=chi2inv(level,Ay);     % output relevant
%Ty2_lim=(Ay*(num^2-1)/(num*(num-Ay)))*finv(level,Ay,num-Ay);

% ———— Q_lim ————
Qx_lim=gx*chi2inv(level,hx);   % potentially output-relevant based on x
Qy_lim=gy*chi2inv(level,hy);   % output relevant

% ———— display results ————
if Ax+1>mm
    display ('Q_x index=0');
end
      
if Ay+1>pp
    display ('Q_y index=0');
end