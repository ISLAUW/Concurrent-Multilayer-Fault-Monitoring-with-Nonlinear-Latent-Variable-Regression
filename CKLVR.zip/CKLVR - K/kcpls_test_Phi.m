function [Tc2_index,Tx2_index,Qx_index,Ty2_index,Qy_index]...
    =kcpls_test(Phi,Phi_test,Y1_test,K0,K1,a,sig_k,R,T,Q,U,Rc,Qc,Px,Py,lamda_c,lamda_x,lamda_y,Ac,Ax,Ay,mm,pp,...
    Tc2_lim,Tx2_lim,Qx_lim,Ty2_lim,Qy_lim)

num=size(Phi,1); num_test=size(Phi_test,1);

Tx2_m=Px*pinv(lamda_x)*Px';
Qx_m=eye(size(Px*Px'))-Px*Px';
Ty2_m=Py*pinv(lamda_y)*Py';
Qy_m=eye(size(Py*Py'))-Py*Py';

for i=1:num_test
    phi=Phi_test(i,:)';
    tc=Rc'*phi; %1 1
    Tc2_index(i)=(num-1)*tc'*tc;
%    Tc2_index(i)=tc'*pinv(lamda_c)*tc; 
    phi_ct=phi-(pinv(Rc'*Rc)*Rc')'*tc;
    yct=Y1_test(i,:)'-Qc*tc;

    Tx2_index(i)=phi_ct'*Tx2_m*phi_ct;
    Ty2_index(i)=yct'*Ty2_m*yct;
    Qx_index(i)=phi_ct'*Qx_m*phi_ct;
    Qy_index(i)=yct'*Qy_m*yct; 
end