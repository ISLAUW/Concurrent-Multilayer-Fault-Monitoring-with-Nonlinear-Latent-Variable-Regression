function Y_predict = klvr_predict(K1,Y1,K1_test,a)
[T,Q,U,C]=klvr(K1,Y1,a);
B=U*pinv(T'*K1*U)*C';
Y_predict=K1_test*B;


