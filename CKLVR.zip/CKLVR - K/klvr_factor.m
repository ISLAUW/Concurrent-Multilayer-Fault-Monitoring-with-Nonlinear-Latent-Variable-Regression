function [a,sig_k]=klvr_factor(X1,Y1)
% choose the number of KLVR factors by cross validation
% call functions: klvr_mse, klvr_predict, klvr    

m=size(X1,1);

for i=1:3
    for j=1:6
        fun=@(XTRAIN,YTRAIN,XTEST,YTEST)(klvr_mse(XTRAIN,YTRAIN,XTEST,YTEST,i,j*900));
        vals=crossval(fun,X1,Y1);
        mse(i,j)=mean(vals);
    end
end
z=min(mse); zz=min(z);
[a,sig_k]=find(mse==zz);
sig_k=900*sig_k;