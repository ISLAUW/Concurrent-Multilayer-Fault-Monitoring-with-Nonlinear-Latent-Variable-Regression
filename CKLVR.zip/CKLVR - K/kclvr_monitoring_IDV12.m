clear all;
close all;
clc;
format short;

%% ———— Data ———— 
% ———— Training Data: Normal Data ————
load d00.dat;  % 52*500 % 每一列为一个指标，每一行为一个样本
% An observation vector at a particular time instant is given by
% x=[XMEAS(1), XMEAS(2), ..., XMEAS(41), XMV(1), ..., XMV(11)]^T
% where XMEAS(n) is the n-th measured variable and XMV(n) is the n-th manipulated variable.

% X0=[d00(1:22,:)',d00(42:52,:)']; Y0=d00(37:41,:)';

% —— Training Data Downsampled ——
T=2; % sampling interval of 37-41
n=size(d00,2)/T;
X0=zeros(n,33); Y0=zeros(n,2); 
for i=1:n
    X0(i,:)=[d00(1:22,(T*i))',d00(42:52,(T*i))']; 
    Y0(i,:)=d00(35:36,(T*i))';
end

% ———— Testing Data ————
load d12_te.dat; % 960*52
X0_te=d12_te;

% X0_test=[X0_te(:,1:22),X0_te(:,42:52)]; 
% Y0_test=X0_te(:,37:41);  

% —— Testing Data Downsampled ——
n_te=size(X0_te,1)/T;
X0_test=zeros(n_te,33); Y0_test=zeros(n_te,2); 
for j=1:n_te
    X0_test(j,:)=[X0_te((T*j),1:22),X0_te((T*j),42:52)]; 
    Y0_test(j,:)=X0_te((T*j),35:36);    
end

%% ————Scale Data————
% ————Scale Training Data————
[X1,mu_x,sig_x]=autos(X0);
[Y1,mu_y,sig_y]=autos(Y0);

% ————Scale Testing Data————
X1_test=autos_test(X0_test,mu_x,sig_x); 
Y1_test=autos_test(Y0_test,mu_y,sig_y); 

%% ———— Perform Cross Validation ————
load klvr_factor_data.mat 
sig_k=5000;
%% ———— Kernel Function ————
[K1,K0]=kernel_function(X1,sig_k); % K1是对高维特征空间进行中心化处理后的核函数
% [Phi,~,~,~,n_pc]=KPCA(X1,X1,sig_k);

%% ———— CKPLS Training ————
[T,C,U,Vc,Dc,Tc,Qc,Wx,Py,Psi,lamda_c,lamda_x,lamda_y,Ac,Ax,Ay,mm,pp,...
    Tc2_lim,Tx2_lim,Qx_lim,Ty2_lim,Qy_lim,T2_lim]...
    =kclvr_train(K1,K0,Y1,a,sig_k);

B=U*pinv(T'*K1*U)*C';
% [~,Phi_test,~,~]=KPCA_0(X1,X1_test,n_pc,sig_k);

% ———— K_test ————
[K1_test,K0_test]=kernel_function_test(X1,X1_test,K0,sig_k);

% ———— MSE ————
Y_predict=K1_test*B;
MSE=sum(sum((Y_predict-Y1_test).^2))/size(Y1_test,1);

%% ———— CKLVR Testing ————
% ———— Obtain the indices for the testing data ————
[Tc2_index_test,Tx2_index_test,Qx_index_test,Ty2_index_test,Qy_index_test,T2_index_test]...
    = kclvr_test(K1_test,K0_test,Y1_test,K1,K0,a,sig_k,T,C,U,Vc,Dc,Tc,Qc,Wx,Py,Psi,lamda_c,lamda_x,lamda_y,Ac,Ax,Ay,mm,pp,...
    Tc2_lim,Tx2_lim,Qx_lim,Ty2_lim,Qy_lim);

%% ———— Plotting ————
n = size(X1_test,1);

figure;
subplot(5,1,1);
plot([1:n],X1_test(:,1));
subplot(5,1,2);
plot([1:n],X1_test(:,2));
subplot(5,1,3);
plot([1:n],X1_test(:,3));
subplot(5,1,4);
plot([1:n],X1_test(:,4));
subplot(5,1,5);
plot([1:n],X1_test(:,5));

% ———— Predicting ————
figure;
subplot(2,1,1)
plot(Y_predict(:,1),'r--');
hold on
plot(Y1_test(:,1),'b');
xlabel('sample number')
ylabel('output value')
legend('predicting data (1)','test data(1)')

subplot(2,1,2)
plot(Y_predict(:,2),'r--');
hold on
plot(Y1_test(:,2),'b');
xlabel('sample number')
ylabel('output value')
legend('predicting data (2)','test data(2)')

% ———— T2 & Q ————
%figure;
%plot([1:n],Tc2_index_test,[1:n],Tc2_lim*ones(1,n),'r');
%title('T_c^2');

%figure;
%plot([1:n],Tx2_index_test,[1:n],Tx2_lim*ones(1,n),'r');
%title('T_x^2');

%figure;
%plot([1:n],Ty2_index_test,[1:n], Ty2_lim*ones(1,n),'r');
%title('T_y^2');

%if Ax+1<=mm
%    figure;
%    plot([1:n],[Qx_index,Qx_index_test], [1:n], Qx_lim*ones(1,n),'r');
%    title('Q_x');
%end

%if Ay+1<=pp
%    figure;
%    plot([1:n],[Qy_index,Qy_index_test], [1:n], Qy_lim*ones(1,n),'r');
%    title('Q_y')
%end

% ———— Plotting together ————
if Ax+1<=mm && Ay+1>pp
    figure;
    subplot(2,2,1);
    plot([1:n],Tc2_index_test,[1:n],Tc2_lim*ones(1,n),'r--');
    xlabel('T_c^2');
    
    subplot(2,2,2);
    plot([1:n],Tx2_index_test,[1:n],Tx2_lim*ones(1,n),'r--');
    xlabel('T_x^2');

    subplot(2,2,3);
    plot([1:n],Ty2_index_test,[1:n],Ty2_lim*ones(1,n),'r--');
    xlabel('T_y^2');

    subplot(2,2,4);
    plot([1:n],Qx_index_test,[1:n],Qx_lim*ones(1,n),'r--');
    xlabel('Q_x');

elseif Ax+1<=mm && Ay+1<=pp
    figure;
    subplot(3,2,1);
    plot([1:n],Tc2_index_test,[1:n],Tc2_lim*ones(1,n),'r--');
    xlabel('T_c^2');

    subplot(3,2,2);
    plot([1:n],Ty2_index_test,[1:n],Ty2_lim*ones(1,n),'r--');
    xlabel('T_y^2');

    subplot(3,2,3);
    plot([1:n],Tx2_index_test,[1:n],Tx2_lim*ones(1,n),'r--');
    xlabel('T_x^2');

    subplot(3,2,4);
    plot([1:n],Qx_index_test,[1:n],Qx_lim*ones(1,n),'r--');
    xlabel('Q_x');

    subplot(3,2,5);
    plot([1:n],Qy_index_test,[1:n],Qy_lim*ones(1,n),'r--');
    xlabel('Q_y');

elseif Ax+1>mm && Ay+1<=pp
    figure;
    subplot(2,2,1);
    plot([1:n],Tc2_index_test,[1:n],Tc2_lim*ones(1,n),'r--');
    xlabel('T_c^2');
    
    subplot(2,2,2);
    plot([1:n],Tx2_index_test,[1:n],Tx2_lim*ones(1,n),'r--');
    xlabel('T_x^2');

    subplot(2,2,3);
    plot([1:n],Ty2_index_test,[1:n],Ty2_lim*ones(1,n),'r--');
    xlabel('T_y^2');

    subplot(2,2,4);
    plot([1:n],Qy_index_test,[1:n],Qy_lim*ones(1,n),'r--');
    xlabel('Q_y');

elseif Ax+1>mm && Ay+1>pp
    figure;
    subplot(2,2,1);
    plot([1:n],Tc2_index_test,[1:n],Tc2_lim*ones(1,n),'r--');
    xlabel('T_c^2');
    
    subplot(2,2,2);
    plot([1:n],Tx2_index_test,[1:n],Tx2_lim*ones(1,n),'r--');
    xlabel('T_x^2');

    subplot(2,2,3);
    plot([1:n],Ty2_index_test,[1:n],Ty2_lim*ones(1,n),'r--');
    xlabel('T_y^2');
end

% ———— Fault detection ————
Tc2_fn=length(Tc2_index_test(Tc2_index_test>Tc2_lim));
Tx2_fn=length(Tx2_index_test(Tx2_index_test>Tx2_lim));
Ty2_fn=length(Ty2_index_test(Ty2_index_test>Ty2_lim));
if Ax+1<=mm
    Qx_fn=length(Qx_index_test(Qx_index_test>Qx_lim));
end
if Ay+1<=pp
    Qy_fn=length(Qy_index_test(Qy_index_test>Qy_lim));
end


%% —————— T2 ——————
%n = size(K1,1); n_test = size(K1_test,1);
% ———— T2_lim ————
alpha = 0.01; level = 1 - alpha; 
T2_lim = (a*(n^2-1)/(n*(n-a)))*finv(level,a,n-a);
% ———— T2 ————
lamda = 1/(size(K1,1)-1)*T'*T;
for i = 1:size(K1_test,1)
    kx_new = K1_test(i,:)';
    t_new = pinv(U'*K1*T)*U'*kx_new;
    % ———— T2_index ————
    T2_index(i) = t_new'*pinv(lamda)*t_new;    
    % ———— Q_index ————
    for j = 1:size(K1,1)
        K0te(j) = K0_test(i,j);
    end
    Kx = 1 - (2/size(K1,1))*sum(K0te) + (1/size(K1,1)^2)*sum(sum(K0));
    Q_index(i) = Kx - 2*kx_new'*T*t_new + t_new'*T'*K1*T*t_new;
end
 

%% —————— KPCA-based monitoring ——————
[Phi_X,Phi_Xt,~,~,~]=KPCA(X1,X1_test,sig_k);
% ———— Obtain the indices from the training data ————
[ax_pca,ay_pca,Tx_pca,Ty_pca,Px_pca,Py_pca,lamda_x_pca,lamda_y_pca,Tx2_lim_pca,Ty2_lim_pca,Qx_lim_pca,Qy_lim_pca] = PCA_train(K1,Y1);
% ———— Obtain the indices for the testing data ————
[Tx2_index_pca_test,Ty2_index_pca_test,Qx_index_pca_test,Qy_index_pca_test] = PCA_test(K1_test,Y1_test,Tx_pca,Ty_pca,Px_pca,Py_pca,lamda_x_pca,lamda_y_pca);

% ———— PCA: T2 & Q ————
%figure;
%plot([1:n],Tx2_index_pca_test,[1:n],Tx2_lim_pca*ones(1,n),'r');
%title('Tx^2');

%figure;
%plot([1:n],Qx_index_pca_test,[1:n],Qx_lim_pca*ones(1,n),'r');
%title('Qx');

%figure;
%plot([1:n],Ty2_index_pca_test,[1:n],Ty2_lim_pca*ones(1,n),'r');
%title('Ty^2');

%figure;
%plot([1:n],Qy_index_pca_test,[1:n],Qy_lim_pca*ones(1,n),'r');
%title('Qy');

% —— Plotting together ——
if ax_pca<size(K1,2) && ay_pca>=size(Y1,2)
    figure;
    subplot(2,2,1);
    plot([1:n],Tx2_index_pca_test,[1:n],Tx2_lim_pca*ones(1,n),'r--');
    xlabel('T_x^2');
    
    subplot(2,2,2);
    plot([1:n],Qx_index_pca_test,[1:n],Qx_lim_pca*ones(1,n),'r--');
    xlabel('Q_x');

    subplot(2,2,3);
    plot([1:n],Ty2_index_pca_test,[1:n],Ty2_lim_pca*ones(1,n),'r--');
    xlabel('T_y^2');

elseif ax_pca<size(K1,2) && ay_pca<size(Y1,2)
    figure;
    subplot(2,2,1);
    plot([1:n],Tx2_index_pca_test,[1:n],Tx2_lim_pca*ones(1,n),'r:');
    xlabel('T_x^2');

    subplot(2,2,2);
    plot([1:n],Qx_index_pca_test,[1:n],Qx_lim_pca*ones(1,n),'r--');
    xlabel('Q_x');

    subplot(2,2,3);
    plot([1:n],Ty2_index_pca_test,[1:n],Ty2_lim_pca*ones(1,n),'r--');
    xlabel('T_y^2');

    subplot(2,2,4);
    plot([1:n],Qy_index_pca_test,[1:n],Qy_lim_pca*ones(1,n),'r--');
    xlabel('Q_y');

elseif ax_pca>=size(K1,2) && ay_pca<size(Y1,2)
    figure;
    subplot(2,2,1);
    plot([1:n],Tx2_index_pca_test,[1:n],Tx2_lim_pca*ones(1,n),'r--');
    xlabel('T_x^2');

    subplot(2,2,2);
    plot([1:n],Ty2_index_pca_test,[1:n],Ty2_lim_pca*ones(1,n),'r--');
    xlabel('T_y^2');

    subplot(2,2,3);
    plot([1:n],Qy_index_pca_test,[1:n],Qy_lim_pca*ones(1,n),'r--');
    xlabel('Q_y');

elseif ax_pca>=size(K1,2) && ay_pca>=size(Y1,2)
    figure;
    subplot(2,2,1);
    plot([1:n],Tx2_index_pca_test,[1:n],Tx2_lim_pca*ones(1,n),'r--');
    xlabel('T_x^2');

    subplot(2,2,2);
    plot([1:n],Ty2_index_pca_test,[1:n],Ty2_lim_pca*ones(1,n),'r--');
    xlabel('T_y^2');

end

Tx2_fn_pca=length(Tx2_index_pca_test(Tx2_index_pca_test>Tx2_lim_pca));
Ty2_fn_pca=length(Ty2_index_pca_test(Ty2_index_pca_test>Ty2_lim_pca));
Qx_fn_pca=length(Qx_index_pca_test(Qx_index_pca_test>Qx_lim_pca));
Qy_fn_pca=length(Qy_index_pca_test(Qy_index_pca_test>Qy_lim_pca));



%% Figure modification of manuscript
% CKLVR
figure;
subplot(4,1,1);
plot([1:n],Tc2_index_test,[1:n],Tc2_lim*ones(1,n),'r--');
title('T_c^2');
legend('statistic','control limit');
    
subplot(4,1,2);
plot([1:n],Tx2_index_test,[1:n],Tx2_lim*ones(1,n),'r--');
title('T_x^2');
legend('statistic','control limit');

subplot(4,1,3);
plot([1:n],Ty2_index_test,[1:n],Ty2_lim*ones(1,n),'r--');
title('T_y^2');
legend('statistic','control limit');

subplot(4,1,4);
plot([1:n],Qx_index_test,[1:n],Qx_lim*ones(1,n),'r--');
title('Q_x');
legend('statistic','control limit');

% PCA
figure;
subplot(3,1,1);
plot([1:n],Tx2_index_pca_test,[1:n],Tx2_lim_pca*ones(1,n),'r--');
title('T_x^2');
legend('statistic','control limit');
    
subplot(3,1,2);
plot([1:n],Qx_index_pca_test,[1:n],Qx_lim_pca*ones(1,n),'r--');
title('Q_x');
legend('statistic','control limit');

subplot(3,1,3);
plot([1:n],Ty2_index_pca_test,[1:n],Ty2_lim_pca*ones(1,n),'r--');
title('T_y^2');
legend('statistic','control limit');




%% ———— Fault Detection Rate (FDR) & Missing Alarm Rate (MAR) & Fault Alarm Rate (FAR) ————        
% ———— T2 ————
TP_T2=zeros(size(X1_test,1),1);
TN_T2=zeros(size(X1_test,1),1);
FP_T2=zeros(size(X1_test,1),1);
FN_T2=zeros(size(X1_test,1),1);

for count=1:size(X1_test,1)
    if  (Tc2_index_test(count) > Tc2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca) || (Ty2_index_test(count) > Ty2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca)
        TP_T2(count)=1;
    elseif (Tc2_index_test(count) < Tc2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca) && (Ty2_index_test(count) < Ty2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca)
        TN_T2(count)=1;
    elseif (Tc2_index_test(count) > Tc2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca) || (Ty2_index_test(count) > Ty2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca)
        FP_T2(count)=1;
    elseif (Tc2_index_test(count) < Tc2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca) && (Ty2_index_test(count) < Ty2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca)
        FN_T2(count)=1;
    end
end

if sum(TP_T2)==0 && sum(FN_T2)==0
    FDR_T2=0
    MAR_T2=0;
else
    FDR_T2=sum(TP_T2)/(sum(TP_T2)+sum(FN_T2))
    MAR_T2=sum(FN_T2)/(sum(TP_T2)+sum(FN_T2));
end

if sum(FP_T2)==0 && sum(TN_T2)==0
    FAR_T2=0
else
    FAR_T2=sum(FP_T2)/(sum(FP_T2)+sum(TN_T2))
end

% ———— Tc2 ————
TP_Tc2=zeros(size(X1_test,1),1);
TN_Tc2=zeros(size(X1_test,1),1);
FP_Tc2=zeros(size(X1_test,1),1);
FN_Tc2=zeros(size(X1_test,1),1);

for count=1:size(X1_test,1)
    if Tc2_index_test(count)>Tc2_lim && Ty2_index_pca_test(count)>Ty2_lim_pca
        TP_Tc2(count)=1;
    elseif Tc2_index_test(count)<Tc2_lim && Ty2_index_pca_test(count)<Ty2_lim_pca
        TN_Tc2(count)=1;
    elseif Tc2_index_test(count)>Tc2_lim && Ty2_index_pca_test(count)<Ty2_lim_pca
        FP_Tc2(count)=1;
    elseif Tc2_index_test(count)<Tc2_lim && Ty2_index_pca_test(count)>Ty2_lim_pca
        FN_Tc2(count)=1;
    end
end

if sum(TP_Tc2)==0 && sum(FN_Tc2)==0
    FDR_Tc2=0
    MAR_Tc2=0;
else
    FDR_Tc2=sum(TP_Tc2)/(sum(TP_Tc2)+sum(FN_Tc2))
    MAR_Tc2=sum(FN_Tc2)/(sum(TP_Tc2)+sum(FN_Tc2));
end

if sum(FP_Tc2)==0 && sum(TN_Tc2)==0
    FAR_Tc2=0;
else
    FAR_Tc2=sum(FP_Tc2)/(sum(FP_Tc2)+sum(TN_Tc2));
end

% ———— Tx2 ————
TP_Tx2=zeros(size(X1_test,1),1);
TN_Tx2=zeros(size(X1_test,1),1);
FP_Tx2=zeros(size(X1_test,1),1);
FN_Tx2=zeros(size(X1_test,1),1);

for count=1:size(X1_test,1)  
    if Tx2_index_test(count)>Tx2_lim && Tx2_index_pca_test(count)>Tx2_lim_pca
        TP_Tx2(count)=1;
    elseif Tx2_index_test(count)<Tx2_lim && Tx2_index_pca_test(count)<Tx2_lim_pca
        TN_Tx2(count)=1;
    elseif Tx2_index_test(count)>Tx2_lim && Tx2_index_pca_test(count)<Tx2_lim_pca
        FP_Tx2(count)=1;
    elseif Tx2_index_test(count)<Tx2_lim && Tx2_index_pca_test(count)>Tx2_lim_pca
        FN_Tx2(count)=1;
    end
end

if sum(TP_Tx2)==0 && sum(FN_Tx2)==0
    FDR_Tx2=0
    MAR_Tx2=0;
else
    FDR_Tx2=sum(TP_Tx2)/(sum(TP_Tx2)+sum(FN_Tx2))
    MAR_Tx2=sum(FN_Tx2)/(sum(TP_Tx2)+sum(FN_Tx2));
end

if sum(FP_Tx2)==0 && sum(TN_Tx2)==0
    FAR_Tx2=0;
else
    FAR_Tx2=sum(FP_Tx2)/(sum(FP_Tx2)+sum(TN_Tx2));
end

% ———— Ty2 ————
TP_Ty2=zeros(size(X1_test,1),1);
TN_Ty2=zeros(size(X1_test,1),1);
FP_Ty2=zeros(size(X1_test,1),1);
FN_Ty2=zeros(size(X1_test,1),1);

for count=1:size(X1_test,1)
    if Ty2_index_test(count)>Ty2_lim && Ty2_index_pca_test(count)>Ty2_lim_pca
        TP_Ty2(count)=1;
    elseif Ty2_index_test(count)<Ty2_lim && Ty2_index_pca_test(count)<Ty2_lim_pca
        TN_Ty2(count)=1;
    elseif Ty2_index_test(count)>Ty2_lim && Ty2_index_pca_test(count)<Ty2_lim_pca
        FP_Ty2(count)=1;
    elseif Ty2_index_test(count)<Ty2_lim && Ty2_index_pca_test(count)>Ty2_lim_pca
        FN_Ty2(count)=1;
    end
end

if sum(TP_Ty2)==0 && sum(FN_Ty2)==0
    FDR_Ty2=0
    MAR_Ty2=0;
else
    FDR_Ty2=sum(TP_Ty2)/(sum(TP_Ty2)+sum(FN_Ty2))
    MAR_Ty2=sum(FN_Ty2)/(sum(TP_Ty2)+sum(FN_Ty2));
end

if sum(FP_Ty2)==0 && sum(TN_Ty2)==0
    FAR_Ty2=0;
else
    FAR_Ty2=sum(FP_Ty2)/(sum(FP_Ty2)+sum(TN_Ty2));
end

% ———— Qx ————
if Ax+1<=mm
    TP_Qx=zeros(size(X1_test,1),1);  
    TN_Qx=zeros(size(X1_test,1),1);
    FP_Qx=zeros(size(X1_test,1),1);
    FN_Qx=zeros(size(X1_test,1),1);

    for count=1:size(X1_test,1)    
        if Qx_index_test(count)>Qx_lim && Qx_index_pca_test(count)>Qx_lim_pca
            TP_Qx(count)=1;
        elseif Qx_index_test(count)<Qx_lim && Qx_index_pca_test(count)<Qx_lim_pca
            TN_Qx(count)=1;
        elseif Qx_index_test(count)>Qx_lim && Qx_index_pca_test(count)<Qx_lim_pca
            FP_Qx(count)=1;
        elseif Qx_index_test(count)<Qx_lim && Qx_index_pca_test(count)>Qx_lim_pca
            FN_Qx(count)=1;
        end
    end
    if sum(TP_Qx)==0 && sum(FN_Qx)==0
        FDR_Qx=0
        MAR_Qx=0;
    else
        FDR_Qx=sum(TP_Qx)/(sum(TP_Qx)+sum(FN_Qx))
        MAR_Qx=sum(FN_Qx)/(sum(TP_Qx)+sum(FN_Qx));
    end
    
    if sum(FP_Qx)==0 && sum(TN_Qx)==0
        FAR_Qx=0;
    else
        FAR_Qx=sum(FP_Qx)/(sum(FP_Qx)+sum(TN_Qx));
    end
end

% ———— Qy ————
if Ay+1<=pp
    TP_Qy=zeros(size(X1_test,1),1);
    TN_Qy=zeros(size(X1_test,1),1);
    FP_Qy=zeros(size(X1_test,1),1);
    FN_Qy=zeros(size(X1_test,1),1);

    for count=1:size(X1_test,1)        
        if Qy_index_test(count)>Qy_lim && Qy_index_pca_test(count)>Qy_lim_pca
            TP_Qy(count)=1;
        elseif Qy_index_test(count)<Qy_lim && Qy_index_pca_test(count)<Qy_lim_pca
            TN_Qy(count)=1;
        elseif Qy_index_test(count)>Qy_lim && Qy_index_pca_test(count)<Qy_lim_pca
            FP_Qy(count)=1;
        elseif Qy_index_test(count)<Qy_lim && Qy_index_pca_test(count)>Qy_lim_pca
            FN_Qy(count)=1;
        end
    end
    if sum(TP_Qy)==0 && sum(FN_Qy)==0
        FDR_Qy=0
        MAR_Qy=0;
    else
        FDR_Qy=sum(TP_Qy)/(sum(TP_Qy)+sum(FN_Qy))
        MAR_Qy=sum(FN_Qy)/(sum(TP_Qy)+sum(FN_Qy));
    end
    
    if sum(FP_Qy)==0 && sum(TN_Qy)==0
        FAR_Qy=0;
    else
        FAR_Qy=sum(FP_Qy)/(sum(FP_Qy)+sum(TN_Qy));
    end
end