%% ————Kernel Function————
function [K1,K0]=kernel_function(X1,sig_k)
num=size(X1,1); 
K(:,:)=zeros(num);
for a=1:num
    K(a,a)=0;
    for b=a+1:num
        xa=X1(a,:); xb=X1(b,:);
        K(a,b)=(norm(xa-xb))^2;
        K(b,a)=K(a,b);           
    end
end
K0=exp(-K/sig_k); 
M=eye(num)-ones(num,num)/num;
K1=M*K0*M; 
end